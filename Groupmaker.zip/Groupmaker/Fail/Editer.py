import os
clas = "Class"
enter_name = "Enter the name you want to edit:  "
replace_name = "Enter the name you want to replace:  "
success = "Success"

pathing = os.path.abspath(os.pardir)
path = os.getcwd()
filepath = os.path.join(path, clas)
for roots, dirs, files in os.walk(filepath):
    break
print (files)

filename = input("Class Name: ")
filepath = os.path.join(pathing, clas)
name =  os.path.join(filepath, filename)
with open(name, 'r+') as hi:
    find_name = input(enter_name)
    original = find_name
    replace_names = input(replace_name)
    hi.replace(enter_name, replace_names)
    hi.write()
print (success)
