from tkinter import *

root = Tk()
root.title("Group Maker")
label = Label(root, text ='Do you want to create a class or create groups?').pack(side= TOP, padx= 5, pady= 15)

def open_classer():
    from function import Classer
def open_grouper():
    from function import Grouper
def exit_window():
    exit()
    
B1 = Button(root, text= "Class", command= open_classer)
B1.pack()
B1.place(relx=0.4, rely=0.95, anchor=CENTER)
B2 = Button(root, text= "Group", command= open_grouper)
B2.pack()
B2.place(relx=0.4, rely=0.95, anchor=CENTER)
B3 = Button(root, text= "Exit", command= exit_window)
B3.pack()
B3.place(relx=0.4, rely=0.95, anchor=CENTER)

root.mainloop()
