function = input('Do you want to create a class or create groups? (class , group):  ')
while True:
    if function == "class":
        from function import Classer
        break
    elif function == "group":
        from function import Grouper
        break
    elif function == "edit":
        from function import Editer
        break
    else:
        print("Erro please enter the correct phraase")
        break
