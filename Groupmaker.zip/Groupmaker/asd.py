import sys

try:
    from Tkinter import *
except ImportError:
    from tkinter import *

try:
    import ttk
    py3 = 0
except ImportError:
    import tkinter.ttk as ttk
    py3 = 1

import unknown_support

def vp_start_gui():
    '''Starting point when module is the main routine.'''
    global val, w, root
    root = Tk()
    unknown_support.set_Tk_var()
    top = Grouper (root)
    unknown_support.init(root, top)
    root.mainloop()

w = None
def create_Grouper(root, *args, **kwargs):
    '''Starting point when module is imported by another program.'''
    global w, w_win, rt
    rt = root
    w = Toplevel (root)
    unknown_support.set_Tk_var()
    top = Grouper (w)
    unknown_support.init(w, top, *args, **kwargs)
    return (w, top)

def destroy_Grouper():
    global w
    w.destroy()
    w = None


class Grouper:
    def __init__(self, top=None):
        '''This class configures and populates the toplevel window.
           top is the toplevel containing window.'''
        _bgcolor = '#d9d9d9'  # X11 color: 'gray85'
        _fgcolor = '#000000'  # X11 color: 'black'
        _compcolor = '#d9d9d9' # X11 color: 'gray85'
        _ana1color = '#d9d9d9' # X11 color: 'gray85' 
        _ana2color = '#d9d9d9' # X11 color: 'gray85' 
        self.style = ttk.Style()
        if sys.platform == "win32":
            self.style.theme_use('winnative')
        self.style.configure('.',background=_bgcolor)
        self.style.configure('.',foreground=_fgcolor)
        self.style.configure('.',font="TkDefaultFont")
        self.style.map('.',background=
            [('selected', _compcolor), ('active',_ana2color)])

        top.geometry("596x267+461+198")
        top.title("Grouper")
        top.configure(background="#d9d9d9")



        self.Frame1 = Frame(top)
        self.Frame1.place(relx=0.02, rely=0.04, relheight=0.88, relwidth=0.96)
        self.Frame1.configure(relief=GROOVE)
        self.Frame1.configure(borderwidth="2")
        self.Frame1.configure(relief=GROOVE)
        self.Frame1.configure(background=_bgcolor)
        self.Frame1.configure(cursor="fleur")
        self.Frame1.configure(width=575)

        self.Label1 = Label(self.Frame1)
        self.Label1.place(relx=0.1, rely=0.09, height=24, width=65)
        self.Label1.configure(background=_bgcolor)
        self.Label1.configure(foreground="#000000")
        self.Label1.configure(text='''Class''')

        self.Label2 = Label(self.Frame1)
        self.Label2.place(relx=0.02, rely=0.17, height=24, width=201)
        self.Label2.configure(background=_bgcolor)
        self.Label2.configure(foreground="#000000")
        self.Label2.configure(text='''Number of Students per Group''')
        self.Label2.configure(width=201)

        self.TCombobox1 = ttk.Combobox(self.Frame1)
        self.TCombobox1.place(relx=0.38, rely=0.04, relheight=0.11
                , relwidth=0.32)
        self.TCombobox1.configure(textvariable=unknown_support.combobox)
        self.TCombobox1.configure(takefocus="")

        self.Entry1 = Entry(self.Frame1)
        self.Entry1.place(relx=0.4, rely=0.17, relheight=0.11, relwidth=0.26)
        self.Entry1.configure(background="white")
        self.Entry1.configure(cursor="fleur")
        self.Entry1.configure(font="TkFixedFont")
        self.Entry1.configure(foreground="#000000")
        self.Entry1.configure(insertbackground="black")

        self.Button1 = Button(self.Frame1)
        self.Button1.place(relx=0.82, rely=0.09, height=22, width=85)
        self.Button1.configure(activebackground="#d9d9d9")
        self.Button1.configure(activeforeground="#000000")
        self.Button1.configure(background=_bgcolor)
        self.Button1.configure(command=unknown_support.Text)
        self.Button1.configure(foreground="#000000")
        self.Button1.configure(highlightbackground="#d9d9d9")
        self.Button1.configure(highlightcolor="black")
        self.Button1.configure(text='''Generate''')

        self.Button2 = Button(self.Frame1)
        self.Button2.place(relx=0.83, rely=0.21, height=22, width=54)
        self.Button2.configure(activebackground="#d9d9d9")
        self.Button2.configure(activeforeground="#000000")
        self.Button2.configure(background=_bgcolor)
        self.Button2.configure(command=root.quit)
        self.Button2.configure(foreground="#000000")
        self.Button2.configure(highlightbackground="#d9d9d9")
        self.Button2.configure(highlightcolor="black")
        self.Button2.configure(text='''Quit''')

        self.Listbox1 = Listbox(self.Frame1)
        self.Listbox1.place(relx=0.03, rely=0.3, relheight=0.66, relwidth=0.35)
        self.Listbox1.configure(background="white")
        self.Listbox1.configure(font="TkFixedFont")
        self.Listbox1.configure(foreground="#000000")
        self.Listbox1.configure(width=202)

        self.Text1 = Text(self.Frame1)
        self.Text1.place(relx=0.4, rely=0.3, relheight=0.69, relwidth=0.59)
        self.Text1.configure(background="white")
        self.Text1.configure(font="TkTextFont")
        self.Text1.configure(foreground="black")
        self.Text1.configure(highlightbackground="#d9d9d9")
        self.Text1.configure(highlightcolor="black")
        self.Text1.configure(insertbackground="black")
        self.Text1.configure(selectbackground="#c4c4c4")
        self.Text1.configure(selectforeground="black")
        self.Text1.configure(width=338)
        self.Text1.configure(wrap=WORD)

    @staticmethod
    def popup1(event):
        _bgcolor = '#d9d9d9'  # X11 color: 'gray85'
        _fgcolor = '#000000'  # X11 color: 'black'
        _compcolor = '#d9d9d9' # X11 color: 'gray85'
        _ana1color = '#d9d9d9' # X11 color: 'gray85' 
        _ana2color = '#d9d9d9' # X11 color: 'gray85' 
        Popupmenu1 = Menu(root, tearoff=0)
        Popupmenu1.configure(activebackground="#f9f9f9")
        Popupmenu1.configure(activeforeground="black")
        Popupmenu1.configure(background=_bgcolor)
        Popupmenu1.configure(disabledforeground="#a3a3a3")
        Popupmenu1.configure(foreground="black")
        Popupmenu1.post(event.x_root, event.y_root)






if __name__ == '__main__':
    vp_start_gui()


