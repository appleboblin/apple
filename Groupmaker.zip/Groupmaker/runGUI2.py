from tkinter import *

root = Tk()
root.resizable(0, 0)
root.geometry("320x70")
root.title("Group Maker")
label = Label(root, text='Do you want to create a class or create groups?').pack(side=TOP, padx=5, pady=15)

def open_classer():
    from function import Classer
def open_grouper():
    from function import Grouper
def open_editer():
    from function import Editer

B1 = Button(root, text="Class", command=open_classer)
B1.pack()
B1.place(relx=0.1, rely=0.95, anchor=SW)
B2 = Button(root, text="Group", command=open_grouper)
B2.pack()
B2.place(relx=0.5, rely=0.95, anchor=S)
B3 = Button(root, text="Edit", command=open_editer)
B3.pack()
B3.place(relx=0.9, rely=0.95, anchor=SE)

root.mainloop()
