#!/usr/bin/env python
import tkinter
from tkinter import *
# define
class Window(Frame):
    def __init__(self, master=None):
        Frame.__init__(self, master)
        self.master = master
        self.init_window()
    def init_window(self):
        self.master.title("Group Maker")
        self.pack(fill=BOTH, expand=1)
        classButton = Button(self, text="Class", command=self.open_classer)
        classButton.place(relx=0.1, rely=0.95, anchor=SW)
        groupButton = Button(self, text="Group", command=self.open_grouper)
        groupButton.place(relx=0.5, rely=0.95, anchor=S)
        editButton = Button(self, text="Edit", command=self.open_editer)
        editButton.place(relx=0.9, rely=0.95, anchor=SE)
    def open_classer(self):
        from function import Classer
    def open_grouper(self):
        from function import Grouper
    def open_editer(self):
        from function import Editer
# window
root = Tk()
root.resizable(0, 0)
label = Label(root, text='Do you want to create a class or create groups?').pack()
root.geometry("300x65")
app = Window(root)
root.mainloop()
