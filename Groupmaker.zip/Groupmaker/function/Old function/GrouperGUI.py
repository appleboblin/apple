from tkinter import *
import random
import os
from tkinter import messagebox
def randomList(a):  # function to randomize a list of students
    b = []
    for i in range(len(a)):  # get the length of the list
        item = random.choice(a)  # get random name from the list
        a.remove(item)  # remove the randomly chosen name from the original list (a)
        b.append(item)  # add the randomly chosen name to the new list (b)
    return b
class Window(Frame):
    def __init__(self, master=None):
        Frame.__init__(self, master)
        self.master = master
        self.init_window()
    def init_window(self):
        self.master.title("Group Maker")
        self.pack(fill=BOTH, expand=1)
    def what_group(self):
        label1.configure(text='How many students per group?')
    def blank(self):
        label2.configure(text=' ')
def chosen_class():
    choice = os.path.join(filepath, file_choice)
    workingClass = open(choice, 'r')
    templist = workingClass.readlines()

    stulist = []  # create an empty list that will be populated with user-chosen class list
    for student in templist:
        temp = student.rstrip('\n')  # strip the newline (\n) character from each list string
        stulist.append(temp)  # add next student from file to the list

    shuffledlist = randomList(stulist)

if __name__ == "__main__":
    root = Tk()
    textFrame = Frame(root)
    entryLabel = Label(textFrame)
    entryLabel["text"] = "Enter class name"
    entryLabel.pack(side=LEFT)
    entryWidget = Entry(textFrame)
    entryWidget["width"] = 50
    textFrame.pack()
    clas = "Class"
    pathing = os.path.abspath(os.pardir)
    path = os.getcwd()

    filepath = os.path.join(path, clas)

    for roots, dirs, files in os.walk(filepath):
        break
        button = Button(root, text="Submit", command=chosen_class)
        firstButton.place(relx=0.1, rely=0.95, anchor=SW)
        butten = Button(root, text="Generate", command=chosen_class)
        secondButton.place(relx=0.9, rely=0.95, anchor=SE)
        root.resizable(0, 0)
        label1 = Label(root, text='What class do you want to randomize?')

        label2 = Label(root, text=files)
        label1.pack()
        label2.pack()
        root.geometry("600x300")
        app = Window(root)
        root.mainloop()
