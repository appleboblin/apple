import tkinter
from tkinter import *
import random
import os
from tkinter import messagebox
def Text():
    def randomList(a):  # function to randomize a list of students
        b = []
        for i in range(len(a)):  # get the length of the list
            item = random.choice(a)  # get random name from the list
            a.remove(item)  # remove the randomly chosen name from the original list (a)
            b.append(item)  # add the randomly chosen name to the new list (b)
        return b
    # open the text file of student data and write it to a list
    choice = os.path.join(filepath, box1.get())
    workingClass = open(choice, 'r')
    templist = workingClass.readlines()

    stulist = []  # create an empty list that will be populated with user-chosen class list
    for student in templist:
        temp = student.rstrip('\n')  # strip the newline (\n) character from each list string
        stulist.append(temp)  # add next student from file to the list
    shuffledlist = randomList(stulist)  # randomize the list
    numstu = int(box2.get())
    while shuffledlist:
        a = shuffledlist[0:numstu]
        shuffledlist[0:numstu] = []


        shuffledlist[0:numstu] = []

    if box2.get().strip() == "":
        messagebox.showerror("Error", "Please enter the correct value")
    else:
        messagebox.showinfo("Groups", "Generated list here")



# Get class list in the "Class" folder
clas = "Class"
pathing = os.path.abspath(os.pardir)  # Get path (exclude the function folder)
path = os.getcwd()  # Get path
# If launching using run.py use path, if running from Grouper.py use pathing
filepath = os.path.join(path, clas)  # join paths

# Get text file containing the class to be randomized from the user
for roots, dirs, files in os.walk(filepath):  # Find files in "Class" folder
    files = [f for f in files if not f[0] == '.']
    dirs[:] = [d for d in dirs if not d[0] == '.']
    break

app = Tk()
app.title("Group Maker")
Label(app, text=files).grid(row=0, column=3)
Label(app, text="Class").grid(row=0)
Label(app, text="Group").grid(row=1)
Label(app, text="How many students in a group?").grid(row=1, column=3)

box1 = Entry(app)
box2 = Entry(app)

box1.grid(row=0, column=1)
box2.grid(row=1, column=1)

Button(app, text='Generate', command=Text).grid(row=0, column=5, sticky=W, pady=4)
Button(app, text='Quit', command=app.quit).grid(row=1, column=5, sticky=W, pady=4)


mainloop( )
