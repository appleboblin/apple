import tkinter as tk
from tkinter import *
from tkinter import ttk
import random
import os
from tkinter import messagebox
import pygubu
class Application:
    def __init__(self, master):

        #1: Create a builder
        self.builder = builder = pygubu.Builder()

        #2: Load an ui file
        builder.add_from_file('Grouper.ui')

        #3: Create the widget using a master as parent
        self.mainwindow = builder.get_object('Window', master)
        def Text():
            def randomList(a):  # function to randomize a list of students
                b = []
                for i in range(len(a)):  # get the length of the list
                    item = random.choice(a)  # get random name from the list
                    a.remove(item)  # remove the randomly chosen name from the original list (a)
                    b.append(item)  # add the randomly chosen name to the new list (b)
                return b
            # open the text file of student data and write it to a list
            choice = os.path.join(filepath, box1.get())
            workingClass = open(choice, 'r')
            templist = workingClass.readlines()

            stulist = []  # create an empty list that will be populated with user-chosen class list
            for student in templist:
                temp = student.rstrip('\n')  # strip the newline (\n) character from each list string
                stulist.append(temp)  # add next student from file to the list
            shuffledlist = randomList(stulist)  # randomize the list
            numstu = int(box2.get())
            while shuffledlist:
                a = shuffledlist[0:numstu]
                shuffledlist[0:numstu] = []


                shuffledlist[0:numstu] = []


if __name__ == '__main__':
    root = tk.Tk()
    app = Application(root)
    root.mainloop()
