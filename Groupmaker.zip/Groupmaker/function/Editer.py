import os
clas = "Class"
enter_name = "Enter the name you want to edit:  "
replace_name = "Enter the name you want to replace:  "
success = "Success"
pathing = os.path.abspath(os.pardir)
path = os.getcwd()
filepath = os.path.join(path, clas)
for roots, dirs, files in os.walk(filepath):
    break
print(files)
while True:
    filename = input("Class Name: ")
    filepath = os.path.join(path, clas)
    name = os.path.join(filepath, filename)
    if filename in files:
        # From Mr. Rock's code : start
        getlist = open(name, "r")
        classlist = getlist.readlines()
        studentlist = []
        for students in classlist:
            liner = students.rstrip('\n')
            studentlist.append(liner)
        print(studentlist)
# End
    else:
        print("Class not Found.")
while True:
    find_name = input(enter_name)
    original = find_name
    if find_name in studentlist:
        after = input(replace_name)
        write_file = open(name, 'r+')
        original_file = open(name)
        with write_file as new_file:
            with original_file as old_file:
                for line in old_file:
                    new_file.write(line.replace(original, after))
        print(success)
        write_file.close()
        original_file.close()
        break
    else:
        print("Name not Found.")
