import os
clas = "Class"
filename = input("Class Name: ")
pathing = os.path.abspath(os.pardir)
path = os.getcwd()
filepath = os.path.join(path, clas)
name = os.path.join(filepath, filename)
target = open(name, 'w')
name = "Enter Names, enter 'done' to  compplete the list"
success = "Succesful Created :  "
print(name)
while True:
    line = input("Student: ")
    if line == "done":
        target.close()
        print(success+filename)
        break
    else:
        target.write(line)
        target.write("\n")
        continue
target.close()