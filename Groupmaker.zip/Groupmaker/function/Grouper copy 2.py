import tkinter
from tkinter import *
from tkinter import ttk
import random
import os
import sys
from tkinter import messagebox
import tkinter.ttk as ttk
def clear():
    text_box.config(state=tkinter.NORMAL)
    text_box.delete(1.0, END)
    text_box.config(state=tkinter.DISABLED)
    random_class()
def write(self):
    text_box.config(state=tkinter.NORMAL)
    text_box.insert(INSERT, self)
    text_box.insert(INSERT, '\n')
    text_box.config(state=tkinter.DISABLED)
def random_class():
    def randomList(a):  # function to randomize a list of students
        b = []
        for i in range(len(a)):  # get the length of the list
            item = random.choice(a)  # get random name from the list
            a.remove(item)  # remove the randomly chosen name from the original list (a)
            b.append(item)  # add the randomly chosen name to the new list (b)
        return b
    # open the text file of student data and write it to a list
    choice = os.path.join(filepath, e1.get())
    workingClass = open(choice, 'r')
    templist = workingClass.readlines()

    stulist = []  # create an empty list that will be populated with user-chosen class list
    for student in templist:
        temp = student.rstrip('\n')  # strip the newline (\n) character from each list string
        stulist.append(temp)  # add next student from file to the list

    shuffledlist = randomList(stulist)  # randomize the list
    numstu = int(e2.get())
    while shuffledlist:  # print randomized groups for the user
        write(shuffledlist[0:numstu])
        shuffledlist[0:numstu] = []


# Get class list in the "Class" folder
clas = "Class"
pathing = os.path.abspath(os.pardir)  # Get path (exclude the function folder)
path = os.getcwd()  # Get path
# If launching using run.py use path, if running from Grouper.py use pathing
filepath = os.path.join(path, clas)  # join paths

# Get text file containing the class to be randomized from the user
for roots, dirs, files in os.walk(filepath):  # Find files in "Class" folder
    files = [f for f in files if not f[0] == '.']
    dirs[:] = [d for d in dirs if not d[0] == '.']
    break

app = Tk()
app.title("Group Maker")
Label(app, text="Class").grid(row=0)
Label(app, text="Group").grid(row=1)

cbp1 = ttk.Labelframe(demoPanel, text='Fully Editable')
cb1 = ttk.Combobox(cbp1)
cb1.pack(pady=5, padx=10)
cbp1.pack(side=TOP, pady=5, padx=10)

e1 = Entry(app)
e2 = Entry(app)

e1.grid(row=0, column=1)
e2.grid(row=1, column=1)
text_box = tkinter.Text(app, state=tkinter.DISABLED)
text_box.grid(row=3, column=1, columnspan=2)
Button(app, text='Generate', command=clear).grid(row=0, column=2, sticky=W, pady=4)
Button(app, text='Quit', command=app.quit).grid(row=1, column=2, sticky=W, pady=4)
app.geometry("600x300")

mainloop( )
